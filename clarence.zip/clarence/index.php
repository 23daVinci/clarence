<?php include "includes/contact_fun.php"; ?>
<!DOCTYPE html>
<html>

<head>

    <!--- basic page needs
   ================================================== -->
    <meta charset="utf-8">
    <title>Mumbai University</title>

    <!-- mobile specific metas
   ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
   ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- script
   ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>

    <!-- favicons
	================================================== -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.icon" type="image/x-icon">
    
</head>

<body id="top">

    <!-- header 
   ================================================== -->
    <header>

        <div class="header-logo">
            <img src="images/logom.png" width="140px" height="140px" alt="">
        </div>

        <a id="header-menu-trigger" href="#0">
            <span class="header-menu-text"></span>

        </a>


    </header>


    <!-- home
   ================================================== -->
    <section id="home" style="background-image: url(images/hero-bg.jpg);">


        <div class="home-content-table">
            <div class="home-content-tablecell">
                <div class="row">
                    <div class="col-twelve">

                        <h3 class="animate-intro">
                            Hello!
                        </h3>
                        <h3 class="animate-intro">Welcome to</h3>
                        <h1 class="animate-intro">
                            Mumbai University
                        </h1>
                        <h4 class="animate-intro" style="color: white">A University that can build your future</h4>

                        <div class="more animate-intro">
                            <a href="login/login.php">
                                <button class="btn">LOGIN</button>
                                <h6 class="animate-intro">for further details</h6>
                            </a>
                        </div>

                    </div> <!-- end col-twelve -->
                </div> <!-- end row -->
            </div> <!-- end home-content-tablecell -->
        </div> <!-- end home-content-table -->
        <!-- end home-social-list -->


    </section> <!-- end home -->


    <!-- notice start -->

    <div class="fluid" style="background-color:#918c8c">
      <br>
      <br>
    
       <h1 style="text-align: center; color: white;">Updates</h1>
        <div class="row">
            <div class="col-sm-2">
                <p> </p>
            </div>
            <div class="col-sm-8">
                <?php include "includes/notice_display.php"; ?>
            </div>
        </div>
        <div class="col-sm-2">
            <p> </p>
        </div>

    </div>



    <!-- contact
   ================================================== -->
    <section id="contact">

    <div class="overlay"></div>

        <div class="row narrow section-intro with-bottom-sep animate-this">
            <div class="col-twelve">
                <h3>Contact</h3>
                <h1>Get In Touch.</h1>

            </div>
        </div> <!-- end section-intro -->

        <div class="row contact-content">

            <div class="col-seven tab-full animate-this">

                <h5>Send Us A Message</h5>

                <!-- form -->
                <form action="" method="post">

                    <div class="form-field">
                        <input name="contactName" type="text" id="contactName" placeholder="Name" value="" minlength="2" required="">
                    </div>

                    <div class="row">
                        <div class="col-six tab-full">
                            <div class="form-field">
                                <input name="contactEmail" type="email" id="contactEmail" placeholder="Email" value="" required="">
                            </div>
                        </div>
                        <div class="col-six tab-full">
                            <div class="form-field">
                                <input name="contactSubject" type="text" id="contactSubject" placeholder="Subject" value="">
                            </div>
                        </div>
                    </div>

                    <div class="form-field">
                        <textarea name="contactMessage" id="contactMessage" placeholder="message" rows="10" cols="50" required=""></textarea>
                    </div>

                    <div class="form-field">
                        <button class="submitform" name="submit">Submit</button>

                        <div id="submit-loader">
                            <div class="text-loader">Sending...</div>
                            <div class="s-loader">
                                <div class="bounce1"></div>
                                <div class="bounce2"></div>
                                <div class="bounce3"></div>
                            </div>
                        </div>
                    </div>

                </form> <!-- end form -->

                <!-- contact-warning -->
                <div id="message-warning"></div>

                <!-- contact-success -->
                <div id="message-success">
                    <i class="fa fa-check"></i>Your message was sent, thank you!<br>
                </div>

            </div> <!-- end col-seven -->

            <div class="col-four tab-full contact-info end animate-this">

                <h5>Contact Information</h5>

                <div class="cinfo">
                    <h6>Where to Find Us</h6>
                    <p>
                        FCRIT-Vashi<br>
                        Opp. Noor Masjid<br>
                        Navi Mumbai
                    </p>
                </div> <!-- end cinfo -->

                <div class="cinfo">
                    <h6>Email Us At</h6>
                    <p>
                        home@mu.com<br>
                        info@mu.com
                    </p>
                </div> <!-- end cinfo -->

                <div class="cinfo">
                    <h6>Call Us At</h6>
                    <p>
                        Phone: (+63) 555 1212<br>
                        Mobile: (+63) 555 0100<br>

                    </p>
                </div>

            </div> <!-- end cinfo -->

        </div> <!-- end row contact-content -->

    </section> <!-- end contact -->

    <!--
   <div id="preloader"> 
    	<div id="loader"></div>
   </div> -->


    <!-- Java Script
   ================================================== -->
    <script src="js/jquery-2.1.3.min.js"></script>
    <!-- <script src="js/plugins.js"></script> -->
    <script src="js/main.js"></script>

</body>

</html>
