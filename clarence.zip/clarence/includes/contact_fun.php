<?php
    $mysql_hostname  =  "localhost";
    $mysql_user  =  "root"; 
    $mysql_password  =  "";
    $mysql_database  =  "univ";

    $conn  =  mysqli_connect($mysql_hostname,$mysql_user,$mysql_password,$mysql_database); 
    if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

if(isset($_POST['submit'])) {
    $name = $_POST['contactName'];
    $email = $_POST['contactEmail'];
    $subject = $_POST['contactSubject'];
    $msg = $_POST['contactMessage'];
    
    $contact_query = "INSERT INTO `contact`(`name`,`email`,`subject`, `message`) VALUES('$name','$email','$subject', '$msg')";
    $contact_result = mysqli_query($conn, $contact_query);
    
    if(!$contact_result) {
        
        die("Could not send your message" . mysqli_error($conn));
    }
    else {
        
        echo "Message sent successfully updated!!";
    }
}

?>