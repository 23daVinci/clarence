<html>
    <head>
        <title></title>
        
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        body,html{
            height: 100%;
            margin: 0;
        }    
        
        .bg{
            background-image: url("images/hero-bg.png");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
/* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}
        th{
            color: white;
        }
        td{
            color: white;
        }

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
    background-color: #A9A9A9;
    color: white;
}
        .cyrus{
            color: white;
        }


    </style>

    </head>
    <body>
     <div class="bg">
      <div class="topnav">
  <a href="index.php">Home</a>
 
  
  <a class="active" href="about.php">About</a>
  <a href="#about">Logout</a>
</div>
      <br>
       <h1 style="text-align: center; color: white">A B O U T</h1>
         <h4 style="text-align: center; color: grey">OUR ESTEEMED UNIVERSITY</h4>
         <div class="container">
         <p class="cyrus"><span><h3>The University of Mumbai</h3></span> (known earlier as University of Bombay) is one of the oldest and premier Universities in India. It was established in 1857 consequent upon "Wood's Education Dispatch", and it is one amongst the first three Universities in India. As a sequel to the change in the name of the city from Bombay to Mumbai, the name of the University has been changed from "University of Bombay" to "University of Mumbai", vide notification issued by the Government of Maharashtra and published in the Government Gazette dated 4th September, 1996. The University was accorded 5 star status in 2001 & 'A' grade status in April 2012 by the National Assessment and Accreditation Council (NAAC). It has been granted University with Potential for Excellence (UPE) status by UGC and PURSE Scheme by DST.</p> 
       <img src="https://sologuides.com/wp-content/uploads/mumbai-golden-palace-interior-825x275.jpg" height="30%" width="60%">
         </div>
        <br>
        <br>
        <br>
        </div>
    </body>
</html>