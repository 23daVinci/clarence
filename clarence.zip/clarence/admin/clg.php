<html>
    <head>
        <title></title>
        
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        body,html{
            height: 100%;
            margin: 0;
        }    
        
        .bg{
            background-image: url("images/hero-bg.png");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
/* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}
        th{
            color: white;
        }
        td{
            color: white;
        }

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
    background-color: #A9A9A9;
    color: white;
}
        th,tr{
            font-size: 25px;
            
        }


    </style>

    </head>
    <body>
     <div class="bg">
      <div class="topnav">
  <a class="active" href="index.php">Home</a>
 
  
  <a href="about.php">About</a>
  <a href="#about">Logout</a>
</div>
      <br>
       <h1 style="text-align: center; color: white">C O L L E G E S</h1>
         <h4 style="text-align: center; color: grey">AFFILIATED TO MUMBAI UNIVERSITY</h4>
         <div class="container"> 
            <table class="table">
             <tr>
                 <th>COLLEGE</th>
                 <th>RANK</th>
                 <th>LOCATION</th>
             </tr>
             <tr>
                 <td>Institute of Chemical Technology</td>
                 <td>1</td>
                 <td>
                    Matunga
                 </td>
                </tr>
                 <tr>
                  <td>VJTI</td>
                 <td>2</td>
                 <td>
                    Matunga
                 </td>
                 </tr>
                 <tr>
                  <td>FCRIT-Vashi</td>
                 <td>3</td>
                 <td>
                    Vashi
                 </td>
                 </tr>
                 <tr>
                  <td>DBIT</td>
                 <td>4</td>
                 <td>
                    Kurla
                 </td>
                 </tr>
                 <tr>
                  <td>KJ Somiaya COE</td>
                 <td>5</td>
                 <td>
                    Sion
                 </td>
                 </tr>
                 <tr>
                  <td>SIES</td>
                 <td>6</td>
                 <td>
                    Nerul
                 </td>
                 </tr>
             
         </table>
         </div>
        <br>
        <br>
        <br>
        </div>
    </body>
</html>