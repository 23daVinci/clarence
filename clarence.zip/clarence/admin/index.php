<html>
    <head>
        <title>University</title>
        
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        body,html{
            height: 100%;
            margin: 0;
        }    
        .bg{
            background-image: url("images/hero-bg.png");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
/* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
    background-color: #A9A9A9;
    color: white;
}
    </style>

    </head>
    <body>
     <div class="bg">
         
     
      <div class="topnav">
  <a class="active" href="#home">Home</a>
  
  
  <a href="about.php">About</a>
  <a href="#about">Logout</a>
</div>
      <br>
       <h1 style="text-align: center; color: white">W E L C O M E</h1>
        <br>
        <br>
        <br>
    <div class="row">
        <div class="col-md-4">
            <div class="container">
                
  <div class="card" style="width:400px">
    <img class="card-img-top" src="images/college.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">COLLEGES</h4>
      <p class="card-text">Our University is affliated to these colleges.</p>
      <a href="clg.php" class="btn btn-primary">Details</a>
    </div>
  </div>
            </div>
        </div>
    
    <div class="col-md-4">
        <div class="container">
                
  <div class="card" style="width:400px">
    <img class="card-img-top" src="images/courses.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">COURSES</h4>
      <p class="card-text">The following courses are provided</p>
      <a href="course.php" class="btn btn-primary">Details</a>
    </div>
  </div>
            </div>
    </div>
    
    <div class="col-md-4">
         <div class="container">
                
  <div class="card" style="width:400px">
    <img class="card-img-top" src="images/news.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">UPDATES</h4>
      <p class="card-text">Updates regarding MU</p>
      <a href="update.php" class="btn btn-primary">Update</a>
    </div>
  </div>
            </div>
    </div>
    </div>
        </div>

    </body>
</html>