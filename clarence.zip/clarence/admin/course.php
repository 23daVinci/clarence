<html>
    <head>
        <title></title>
        
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
         body,html{
            height: 100%;
            margin: 0;
        }    
        
        .bg{
            background-image: url("images/hero-bg.png");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        
        footer{
            background-color: black;
            height: 100%;
            background-repeat: repeat;
            
        }
/* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
    background-color: #A9A9A9;
    color: white;
}
        th,tr{
            color: white;
            font-size: 30px;
        }
    </style>

    </head>
    <body>
     <div class="bg">
      <div class="topnav">
  <a class="active" href="index.php">Home</a>

  
  <a href="about.php">About</a>
  <a href="#about">Logout</a>
</div>
      <br>
       <h1 style="text-align: center; color: white">C O U R S E S</h1>
       <h4 style="text-align: center; color: grey">BY MUMBAI UNIVERSITY</h4>
       
           <div class="container"> 
            <table class="table">
             <tr rowspan=3>
                 <th>ICT,Matunga</th>
                
             </tr>
             <tr>
                 <th>COURSE</th>
                 <th>DEGREE</th>
                 <th>DIPLOMA</th>
             </tr>
             <tr>
                 <td>Computer Science</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                </tr>
                 <tr>
                  <td>IT</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Mechanical</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Civil</td>
                 <td>NOT PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Chemical</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Electrical/EXTC</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
             
         </table>
         <br>
         <br>
         <br>
    
         <table class="table">
             <tr rowspan=3>
                 <th>VJTI</th>
                
             </tr>
             <tr>
                 <th>COURSE</th>
                 <th>DEGREE</th>
                 <th>DIPLOMA</th>
             </tr>
             <tr>
                 <td>Computer Science</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                </tr>
                 <tr>
                  <td>IT</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Mechanical</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 
                 <tr>
                  <td>Chemical</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
                 
             
         </table>
         <table class="table">
             <tr rowspan=3>
                 <th>FCRIT,Vashi</th>
                
             </tr>
             <tr>
                 <th>COURSE</th>
                 <th>DEGREE</th>
                 <th>DIPLOMA</th>
             </tr>
             <tr>
                 <td>Computer Science</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                </tr>
                 <tr>
                  <td>IT</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Mechanical</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Civil</td>
                 <td>NOT PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Chemical</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Electrical/EXTC</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
             
         </table>
         <table class="table">
             <tr rowspan=3>
                 <th>KJ Somaiya, Sion</th>
                
             </tr>
             <tr>
                 <th>COURSE</th>
                 <th>DEGREE</th>
                 <th>DIPLOMA</th>
             </tr>
             <tr>
                 <td>Computer Science</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                </tr>
                 <tr>
                  <td>IT</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Mechanical</td>
                 <td>PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Civil</td>
                 <td>NOT PROVIDED</td>
                 <td>
                    NOT PROVIDED
                 </td>
                 </tr>
                 <tr>
                  <td>Chemical</td>
                 <td>PROVIDED</td>
                 <td>
                    PROVIDED
                 </td>
                 </tr>
                 
             
         </table>
         </div>
       
        <br>
        <br>
        <br>
        </div>
    <footer>
        
    </footer>
    <footer>
        
    </footer>
    </body>
</html>