<?php include "includes/alogin_fun.php"; ?>
   <html>
    <head>
        <title>Mumbai University</title>
        
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <style type="text/css"> 
            
            body,html{
            height: 100%;
            margin: 0;
        }    
        
        .bg1{
            background-image: url("images/hero-bg.png");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
            .luck{
                align-content: center;
                
            }
            header{
                height: 20%;
                width:auto;
                background-color: black;
            }
        </style>
    </head>
    <body>
    <header>
         
    </header>
   
    <div class="bg1">
    
    <div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div><span></span></div>
		</div>
		<br>
		<div class="row">
		    <div class="col-sm-4">
		        <p>  </p>
		    </div>
		    <div class="col-sm-4 jumbotron">
		        <form action="" method="post">
                <label for="">Username</label>
		            <input type="text" name="username" class="form-control">
                <label for="">Password</label>
		            <input type="text" name="password" class="form-control"><br>
		          <input type="submit" class="btn btn-warning" style="position: relative; left: 200px;" name="login" value="LOGIN">
		        </form>
		    </div>
		</div>
        </div>
        
    </body>
</html>