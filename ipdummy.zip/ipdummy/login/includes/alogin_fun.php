
<?php session_start();  

$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="";
$db['db_name']="univ";
 
foreach($db as $key => $value){
	define(strtoupper($key),$value);
	
}


$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);



include("function.php");

if(isset($_POST['login'])){

$username = $_POST['username'];
$password = $_POST['password'];
    
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);
    

$username = string_check($username);
$password = string_check($password);



$query = "SELECT * FROM users where username= '$username'";
	
$select_admin_query = mysqli_query($conn,$query);


if(!$select_admin_query ){
	die("Error ocurred ".mysqli_error($conn));
}

        while($row = mysqli_fetch_array($select_admin_query)){
        $user_name=$row['username'];
        $user_password = $row['password'];
        $name = $row['name'];
        $user_image = $row['image'];
            
    }
    
  
    $password = crypt($password,$user_password);
	$password = substr($password,0,50);
	echo $password."<br>";
	
	
	if($password !== $user_password && $username !== $user_name){
        header("Location:login.php");
        echo "Invalid username or password";
    }
    

	
	else	if($password == $user_password && $username == $user_name){
            
        
            $_SESSION['userId'] = x;
			$_SESSION['firstname'] = $fname;
            $_SESSION['lastname'] = $lname;
        
            $_SESSION['user_email'] = $email;
            $_SESSION['uimage'] = $user_image;
            
            
            
           
            
            
			echo"<br> password";
			header("Location:../admin/index.php");
		}
    
		else{
			echo"<br>invalid password";
        }
    
}

	
	

?>


