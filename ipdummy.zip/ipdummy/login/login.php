<?php include "includes/alogin_fun.php"; ?>
   <html>
    <head>
        <title>QBank</title>
        <link rel="stylesheet" href="css/login.css">
    </head>
    <body>
    <div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div>QBank<span> Login</span></div>
		</div>
		<br>
		<form action="" method="post" autocomplete="off">
		<div class="login">
				<input type="text" placeholder="username" name="username"><br>
				<input type="password" placeholder="password" name="password"><br>
				<input type="submit" value="Login" name="login">
		</div>
        </form>
    </body>
</html>