
<?php
                    
    $mysql_hostname  =  "localhost";
    $mysql_user  =  "root"; 
    $mysql_password  =  "";
    $mysql_database  =  "univ";

    $conn  =  mysqli_connect($mysql_hostname,$mysql_user,$mysql_password,$mysql_database); 
    if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
ul {
    
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
 header{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;
    }
  footer{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;

    }
  
li {
    float: left;
}
li a {
    display: block;
    color: white;
    text-align: center;
    text-align: left;

    padding: 14px 16px;
    text-decoration: none;
}
.active{
  background-color: green;
}

</style>
</head>
<body style="background-color: #a3c1fd">
  <header><h1>Enter text</h1></header>
<ul>
  <li><a class="active" href="home.html">Home</a></li>
  <li><a href="news.html">News</a></li>
  <li><a href="about.html">About</a></li>
</ul>


<div>
<?php
  $query = "SELECT * FROM notices";
  $result = mysqli_query($conn, $query);
  while($row = mysqli_fetch_array($result))
           { ?>
           <!-- News Posts Small -->
           <div>
           <?php echo "<h4 style= 'color: white;'>" . $row['notice1'] . "</h4>"; ?>
           </div>

           <!-- News Posts Small -->
           <div>
           <?php echo "<h4 style=' color: white;'>" . $row['notice2'] . "</h4>"; ?>
           </div>

           <!-- News Posts Small -->
           <div>
           <?php echo "<h4 style='color: white;'>" . $row['notice3'] . "</h4>"; ?>
           </div>

  <?php }
     mysqli_close($conn);
   ?>
    </div>
    <button onclick="btnClick()">click me!</button>
    <script>
        
       function btnClick() {
            alert("something");
        }
    </script>
</body>
</html>
