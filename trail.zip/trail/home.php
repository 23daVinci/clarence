<?php include "includes/notice-display.php"; ?>
<!DOCTYPE html>
<html>
<head>
<style>
ul {
    
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
 header{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;
    }
  footer{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;

    }
  
li {
    float: left;
}
li a {
    display: block;
    color: white;
    text-align: center;
    text-align: left;

    padding: 14px 16px;
    text-decoration: none;
}
.active{
  background-color: green;
}

</style>
</head>
<body style="background-color: #a3c1fd">
  <header><h1>Enter text</h1></header>
<ul>
  <li><a class="active" href="home.html">Home</a></li>
  <li><a href="news.html">News</a></li>
  <li><a href="about.html">About</a></li>
</ul>


<div>
  <?php include "includes/notice_entry.php"; ?>
<table style="width: 100%">
  <th>
    <td style="font-size: 30px">The blah blah</td>
  </th>
  <tr>
    <td>hjdhjhjdhj</td>

  </tr>
  <tr>
    <td>hjdhjhjdhj</td>

  </tr>
  <tr>
    <td>hjdhjhjdhj</td>

  </tr>
  
</table>

</body>
</html>
