<?php include "includes/notice_entry.php"; ?>
<!DOCTYPE html>
<html>
<head>
<style>
  ul{
    
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  header{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;
  }
  footer{
    background-color: grey;
    font-size: 20px;
    font-style: Times New Roman;
    text-align: center;
    height: 100px;
    color: white;

  }
  li{
    float: left;
  }
   
  li a{
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  .active{
    background-color: green;
  }
  table{
    background-color: white;

  }
 
</style>
</head>

<body style="background-color: #a3c1fd">
    <header><div class="a"><h1>Enter text</h1></div></header>
  <ul>
    <li><a href="home.html">Home</a></li>
    <li><a class="active" href="news.html">News</a></li>
    <li><a href="about.html">About</a></li>
  </ul>
                  <form action="" method="post">
                    <table>
                    <tr>
                      <td><p style="color: black;">Notice 1:</p><input type="text" name="notice1"></td>
                    </tr>
                    <br>
                    <tr><td><p style="color: black;">Notice 2:</p><input type="text" name="notice2"></td></tr>
                    <br>
                    <tr><td><p style="color: black;">Notice 3:</p><input type="text" name="notice3"></td></tr>
                    <br>
                    <br>
                  </table>
                    <button type="submit" onclick="reset()" name="reset_notice">Reset</button>
                    <input type="submit"  value="Update" name="update_notice">
                </form>
                
                <script>
                    function reset() {
                        alert("Notice section ready to be written!!");
                    }
    </script>
</body>
</html>
